# LEXIGUESS app

A vocabulary and comprehension game for grades 7 to 12. It **always works offline**. When the device is online, finished runs also go to a **worldwide Top 100 leaderboard for every grade** (Today and All time).

## How offline and online work together
- Play, progress and levels are saved on the device. No internet is needed to play.
- A run of 15/30 or more is sent to the online leaderboard. If the device is offline, the run waits in a queue and uploads by itself later.
- The leaderboard shows the live Top 100 when online. Offline it shows the last saved board, or this device's board if none was saved.
- A small chip shows 🟢 Online, 📴 Offline or 💾 Offline mode.

## 1. Run it (website + leaderboard server)
    npm start            # http://localhost:3000
`server.js` serves the game and the leaderboard API. Needs Node 18 or newer and no packages.

Settings (environment variables, all optional):

| Variable | Default | What it does |
|---|---|---|
| `PORT` | 3000 | Port to listen on |
| `DATA_DIR` | `./data` | Where `leaderboard.json` is saved. **Use a persistent disk**, or the board is lost when the host restarts |
| `TRUST_PROXY` | off | Set to `1` on Render, Railway, Fly and similar hosts, so each visitor gets their own rate limit |
| `BOARD_TZ_OFFSET` | 8 | Hours from UTC for the "Today" board (8 = Philippines). It refreshes at local midnight |
| `ADMIN_TOKEN` | off | 16+ characters. Turns on the route to remove a bad nickname (see below) |
| `ALLOWED_ORIGIN` | `*` | Restrict who may call the API from another site |
| `API_RATE_LIMIT` / `POST_RATE_LIMIT` / `RATE_LIMIT` | 600 / 60 / 120 | Requests per minute per IP (reads / score uploads / files) |
| `MIN_TIME_MS` | 30000 | Finish times faster than this are rejected as not real |

Remove a nickname (only works if `ADMIN_TOKEN` is set):

    curl -X POST https://YOUR-SITE/api/admin/remove -H "Content-Type: application/json" -H "Authorization: Bearer YOUR_TOKEN" -d '{"name":"BadName"}'

Hosting note: the leaderboard needs a Node host (Render, Railway, Fly, a VPS). Static-only hosts (GitHub Pages, Netlify without functions) can still show the game, but the leaderboard will be offline-only there.

## 2. Single file
Open `public/index.html`, or the separate `LEXIGUESS__Vocabulary_Interactive_Game.html`, in any browser. It plays offline. To turn on the online leaderboard, set `SERVER_URL` near the top of the script, for example `const SERVER_URL='https://lexiguess.onrender.com';`.

## 3. Installable app (PWA)
Host `public/` with `server.js` on HTTPS. On a phone, open the site once, then "Add to Home screen". After the first visit it opens offline. Pages update by themselves when online. If you change icons, change `CACHE` in `public/sw.js` (for example `v4`).

## 4. Android / iOS store apps (Capacitor)
In `public/index.html` set `SERVER_URL` to your deployed https server first. Then run:

    npm i @capacitor/core
    npm i -D @capacitor/cli
    npm i @capacitor/android @capacitor/ios
    npx cap add android
    npx cap add ios --packagemanager SPM     # iOS needs a Mac with Xcode
    npx cap sync
    npx cap open android                      # or: npx cap open ios
Run `npx cap sync` after every change in `public/`.

## Privacy and safety notes
- Players are identified by a random id kept on their device. Only the nickname, grade, score and time are public.
- The name screen tells students to use a nickname. "Reset My Progress" also asks the server to delete that player's entries.
- Scores are reported by the game, so a determined cheater could fake one. The server checks ranges, a minimum finish time and rate limits, and you can remove entries with the admin route.
