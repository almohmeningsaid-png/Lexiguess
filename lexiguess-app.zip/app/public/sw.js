// Offline cache for LEXIGUESS. Bump CACHE when you change icons or other non-HTML files.
const CACHE = 'lexiguess-offline-v3';
const APP_SHELL = ['./', './index.html', './manifest.webmanifest', './icon.svg', './icon-180.png', './icon-192.png', './icon-512.png'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const req = event.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/')) return;                       // leaderboard data is never cached here: the game keeps its own saved copy
  const keep = response => { if (response.ok) { const copy = response.clone(); caches.open(CACHE).then(cache => cache.put(req, copy)); } return response; };
  if (req.mode === 'navigate') {
    // pages: newest version when online, saved copy when offline
    event.respondWith(fetch(req).then(keep).catch(() => caches.match('./index.html')));
    return;
  }
  event.respondWith(caches.match(req).then(cached => cached || fetch(req).then(keep).catch(() => Response.error())));
});
