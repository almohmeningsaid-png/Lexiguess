import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = path.resolve('public');

// Environment variables are read once and validated. Nothing here is a secret except ADMIN_TOKEN (optional).
const intEnv = (name, fallback, min, max) => {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return fallback;
  const n = Number(raw);
  return Number.isInteger(n) && n >= min && n <= max ? n : fallback;
};
const port = intEnv('PORT', 3000, 1, 65535);
const RATE_LIMIT = intEnv('RATE_LIMIT', 120, 1, 100000);            // static files per minute per IP
const API_RATE_LIMIT = intEnv('API_RATE_LIMIT', 600, 1, 100000);    // leaderboard reads per minute per IP (a whole class can share one IP)
const POST_RATE_LIMIT = intEnv('POST_RATE_LIMIT', 60, 1, 100000);   // score submissions per minute per IP
const TRUST_PROXY = process.env.TRUST_PROXY === '1';                // set to 1 on Render/Railway/Fly so each visitor gets their own limit
const DATA_DIR = path.resolve(process.env.DATA_DIR || 'data');       // put this on a persistent disk so the leaderboard survives restarts
const TZ_OFFSET = intEnv('BOARD_TZ_OFFSET', 8, -12, 14);            // hours from UTC for the "Today" board (8 = Philippines)
const MIN_TIME_MS = intEnv('MIN_TIME_MS', 30000, 0, 600000);        // a full 30-point run cannot be finished faster than this
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';            // e.g. https://yourgame.example.com ('*' lets the phone app and single file talk to the server)
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';                   // optional, 16+ characters. If empty, the admin route is switched off.
const TOP = 100, MAX_PLAYERS = 200000, QUALIFY = 15;

const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.webmanifest': 'application/manifest+json' };

// Security headers sent with every response (a plain HTML file cannot set these itself).
const security = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Resource-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; manifest-src 'self'; worker-src 'self'; object-src 'none'; media-src 'none'; frame-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"
};
const cors = {
  'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, X-Player-Id',
  'Access-Control-Max-Age': '86400',
  'Vary': 'Origin'
};

/* ---------------- rate limits (in memory, per IP and per kind) ---------------- */
const hits = new Map();
setInterval(() => { const now = Date.now(); for (const [k, h] of hits) if (h.reset <= now) hits.delete(k); }, 60000).unref();
function limited(req, kind, max) {
  let ip = req.socket.remoteAddress || 'unknown';
  if (TRUST_PROXY) ip = String(req.headers['x-forwarded-for'] || ip).split(',')[0].trim().slice(0, 64);
  const key = kind + ':' + ip, now = Date.now();
  let h = hits.get(key);
  if (!h || h.reset <= now) { h = { count: 0, reset: now + 60000 }; hits.set(key, h); }
  h.count++;
  return h.count > max ? Math.ceil((h.reset - now) / 1000) : 0;
}

function send(res, status, headers, body) {
  res.writeHead(status, { ...security, ...headers });
  res.end(body);
}
const text = { 'Content-Type': 'text/plain; charset=utf-8' };
const jsonH = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Cross-Origin-Resource-Policy': 'cross-origin', ...cors };
const sendJson = (res, status, obj, extra = {}) => send(res, status, { ...jsonH, ...extra }, JSON.stringify(obj));

/* ---------------- leaderboard storage (one JSON file) ---------------- */
// players: { pid: { n: name } }   all: { grade: { pid: {t,s,r} } }   today: { grade: { d: 'YYYY-MM-DD', e: { pid: {t,s,r} } } }
let db = { v: 1, players: {}, all: {}, today: {} };
const dbFile = path.join(DATA_DIR, 'leaderboard.json');
try {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (fs.existsSync(dbFile)) {
    try {
      const j = JSON.parse(fs.readFileSync(dbFile, 'utf8'));
      if (j && j.v === 1 && j.players && j.all && j.today) db = j;
    } catch { fs.renameSync(dbFile, dbFile + '.bak-' + Date.now()); console.error('leaderboard.json was damaged; started a new one (old file kept as .bak)'); }
  }
} catch (e) { console.error('Cannot use DATA_DIR, leaderboard will not be saved:', e.code || e.message); }

let dirty = false, timer = null;
function persist() {
  dirty = true;
  if (timer) return;
  timer = setTimeout(flush, 1500); timer.unref();
}
function flush() {
  timer = null;
  if (!dirty) return;
  dirty = false;
  try {
    const tmp = dbFile + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, dbFile);
  } catch (e) { console.error('Could not save leaderboard:', e.code || e.message); dirty = true; }
}
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { flush(); process.exit(0); });

const dayKey = (now = Date.now()) => new Date(now + TZ_OFFSET * 3600000).toISOString().slice(0, 10);
const msToReset = (now = Date.now()) => { const t = now + TZ_OFFSET * 3600000, d = new Date(t); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1) - t; };
function todayMap(g) {
  const k = dayKey(), b = db.today[g];
  if (!b || b.d !== k) db.today[g] = { d: k, e: {} };
  return db.today[g].e;
}
const better = (a, b) => !b || a.t < b.t || (a.t === b.t && a.s > b.s);
const cmp = (a, b) => a.t - b.t || b.s - a.s || a.at - b.at;
const sortedCache = new Map();           // `${period}:${grade}` -> sorted rows (cleared on every change)
function rowsFor(period, g) {
  const key = period + ':' + g + ':' + (period === 'today' ? dayKey() : '');
  let rows = sortedCache.get(key);
  if (!rows) {
    const m = period === 'today' ? todayMap(g) : (db.all[g] || {});
    rows = Object.entries(m).map(([pid, e]) => ({ pid, n: (db.players[pid] || {}).n || 'Player', t: e.t, s: e.s, r: e.r, at: e.at || 0 })).sort(cmp);
    sortedCache.set(key, rows);
  }
  return rows;
}

const cleanName = v => String(v ?? '').normalize('NFKC').replace(/[^\p{L}\p{M}'\- ]/gu, '').replace(/\s+/g, ' ').trim().slice(0, 16);
const isPid = v => typeof v === 'string' && /^[a-f0-9]{32}$/.test(v);
const intIn = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;

function board(g, period, pid) {
  const rows = rowsFor(period, g), out = rows.slice(0, TOP).map((x, i) => ({ rank: i + 1, n: x.n, t: x.t, s: x.s, r: x.r, me: x.pid === pid }));
  let mine = null;
  if (pid) { const i = rows.findIndex(x => x.pid === pid); if (i >= TOP) mine = { rank: i + 1, n: rows[i].n, t: rows[i].t, s: rows[i].s, r: rows[i].r, me: true }; }
  return { grade: g, period, total: rows.length, rows: out, mine, resetsIn: period === 'today' ? msToReset() : null, serverTime: Date.now() };
}

function submit(b) {
  if (!b || typeof b !== 'object') return [400, { error: 'Bad request' }];
  const name = cleanName(b.name), g = b.grade, s = b.score, t = b.time, r = b.round;
  if (!isPid(b.pid) || !name || !intIn(g, 7, 12) || !intIn(s, 0, 30) || !intIn(t, 1, 86400000) || !intIn(r, 1, 1000)) return [400, { error: 'Invalid score' }];
  if (!db.players[b.pid] && Object.keys(db.players).length >= MAX_PLAYERS) return [503, { error: 'Leaderboard is full' }];
  if (s < QUALIFY) return [200, { ok: true, ranked: false }];
  if (t < MIN_TIME_MS) return [422, { error: 'Time is too short to be real' }];
  const at = Date.now(), cand = { t, s, r, at };
  (db.players[b.pid] ||= {}).n = name;
  const all = (db.all[g] ||= {});
  if (better(cand, all[b.pid])) all[b.pid] = cand;
  const td = todayMap(g);
  if (better(cand, td[b.pid])) td[b.pid] = cand;
  sortedCache.clear(); persist();
  const rk = (period) => rowsFor(period, g).findIndex(x => x.pid === b.pid) + 1;
  return [200, { ok: true, ranked: true, rank: { today: rk('today'), all: rk('all') }, total: { today: rowsFor('today', g).length, all: rowsFor('all', g).length } }];
}
function forget(pid) {
  let n = 0;
  if (db.players[pid]) { delete db.players[pid]; n++; }
  for (const g of Object.keys(db.all)) if (db.all[g][pid]) { delete db.all[g][pid]; n++; }
  for (const g of Object.keys(db.today)) if (db.today[g].e[pid]) { delete db.today[g].e[pid]; n++; }
  if (n) { sortedCache.clear(); persist(); }
  return n;
}

function readBody(req, res, cb) {
  const ct = String(req.headers['content-type'] || '');
  if (!ct.toLowerCase().startsWith('application/json')) { sendJson(res, 415, { error: 'JSON only' }); return; }
  let size = 0; const chunks = [];
  req.on('data', c => { size += c.length; if (size > 2048) { sendJson(res, 413, { error: 'Too large' }); req.destroy(); } else chunks.push(c); });
  req.on('end', () => { if (res.writableEnded) return; try { cb(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { sendJson(res, 400, { error: 'Bad JSON' }); } });
  req.on('error', () => {});
}
const sha = v => crypto.createHash('sha256').update(String(v)).digest();

function api(req, res, url) {
  const route = url.pathname;
  if (req.method === 'OPTIONS') { send(res, 204, { ...cors, 'Cache-Control': 'no-store' }); return; }
  if (req.method === 'POST') { const w = limited(req, 'post', POST_RATE_LIMIT); if (w) { sendJson(res, 429, { error: 'Too many requests' }, { 'Retry-After': String(w) }); return; } }
  else { const w = limited(req, 'api', API_RATE_LIMIT); if (w) { sendJson(res, 429, { error: 'Too many requests' }, { 'Retry-After': String(w) }); return; } }

  if (req.method === 'GET' && route === '/api/ping') { sendJson(res, 200, { ok: true, time: Date.now() }); return; }
  if (req.method === 'GET' && route === '/api/leaderboard') {
    const g = Number(url.searchParams.get('grade')), period = url.searchParams.get('period') === 'all' ? 'all' : 'today';
    const pid = String(req.headers['x-player-id'] || '');
    if (!intIn(g, 7, 12)) { sendJson(res, 400, { error: 'Grade must be 7 to 12' }); return; }
    sendJson(res, 200, board(g, period, isPid(pid) ? pid : ''));
    return;
  }
  if (req.method === 'POST' && route === '/api/score') { readBody(req, res, b => { const [st, o] = submit(b); sendJson(res, st, o); }); return; }
  if (req.method === 'POST' && route === '/api/rename') {
    readBody(req, res, b => {
      const name = cleanName(b && b.name);
      if (!b || !isPid(b.pid) || !name) { sendJson(res, 400, { error: 'Invalid name' }); return; }
      if (db.players[b.pid]) { db.players[b.pid].n = name; sortedCache.clear(); persist(); }
      sendJson(res, 200, { ok: true });
    });
    return;
  }
  if (req.method === 'POST' && route === '/api/forget') {
    readBody(req, res, b => { if (!b || !isPid(b.pid)) { sendJson(res, 400, { error: 'Invalid id' }); return; } sendJson(res, 200, { ok: true, removed: forget(b.pid) }); });
    return;
  }
  if (req.method === 'POST' && route === '/api/admin/remove') {
    if (ADMIN_TOKEN.length < 16) { sendJson(res, 404, { error: 'Not found' }); return; }   // route is off unless a long token is set
    const auth = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!crypto.timingSafeEqual(sha(auth), sha(ADMIN_TOKEN))) { sendJson(res, 401, { error: 'Unauthorized' }); return; }
    readBody(req, res, b => {
      let removed = 0;
      if (b && isPid(b.pid)) removed = forget(b.pid);
      else if (b && typeof b.name === 'string' && b.name.trim()) {
        const want = cleanName(b.name).toLowerCase();
        for (const [pid, p] of Object.entries(db.players)) if (String(p.n).toLowerCase() === want) removed += forget(pid);
      } else { sendJson(res, 400, { error: 'Send {"name":"..."} or {"pid":"..."}' }); return; }
      sendJson(res, 200, { ok: true, removed });
    });
    return;
  }
  sendJson(res, 404, { error: 'Not found' });
}

/* ---------------- static files ---------------- */
// Returns a file path inside /public, or null for anything unsafe or not allowed.
function safeFile(urlPath) {
  let pathname;
  try { pathname = decodeURIComponent((urlPath || '/').split('?')[0]); } catch { return null; }
  if (pathname.includes('\0') || pathname.includes('\\')) return null;
  if (pathname.split('/').some(seg => seg.startsWith('.'))) return null;      // no hidden files (.env, .git ...)
  const requested = pathname === '/' ? '/index.html' : pathname;
  const file = path.resolve(root, '.' + requested);
  if (!file.startsWith(root + path.sep)) return null;
  return types[path.extname(file).toLowerCase()] ? file : null;                 // only known public file types
}

const server = http.createServer((req, res) => {
  let url;
  try { url = new URL(req.url || '/', 'http://x'); } catch { send(res, 400, text, 'Bad request'); return; }
  if ((req.url || '').length > 2048) { send(res, 414, text, 'URI too long'); return; }
  if (url.pathname.startsWith('/api/')) { api(req, res, url); return; }
  const wait = limited(req, 'static', RATE_LIMIT);
  if (wait) { send(res, 429, { ...text, 'Retry-After': String(wait) }, 'Too many requests'); return; }
  if (req.method !== 'GET' && req.method !== 'HEAD') { send(res, 405, { ...text, Allow: 'GET, HEAD' }, 'Method not allowed'); return; }
  if (req.url === '/health') { send(res, 200, { ...text, 'Cache-Control': 'no-store' }, 'ok'); return; }
  if (req.url === '/-routes.json') {
    send(res, 200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, JSON.stringify({ routes: [{ path: '/', title: 'LEXIGUESS Vocabulary Game' }] }));
    return;
  }
  const file = safeFile(req.url);
  if (!file) { send(res, 404, text, 'Not found'); return; }
  fs.readFile(file, (err, data) => {
    if (err) { send(res, err.code === 'ENOENT' || err.code === 'EISDIR' ? 404 : 500, text, err.code === 'ENOENT' || err.code === 'EISDIR' ? 'Not found' : 'Server error'); return; }
    send(res, 200, { 'Content-Type': types[path.extname(file).toLowerCase()], 'Cache-Control': 'no-cache' }, req.method === 'HEAD' ? undefined : data);
  });
});

// Slow-client protection and no stack traces or debug output sent to visitors.
server.headersTimeout = 10000;
server.requestTimeout = 15000;
server.keepAliveTimeout = 5000;
server.maxHeadersCount = 50;
server.listen(port, '0.0.0.0', () => console.log(`LEXIGUESS listening on ${port}`));
